module.exports =
  'Historia y conceptos de diseño del videojuego'
